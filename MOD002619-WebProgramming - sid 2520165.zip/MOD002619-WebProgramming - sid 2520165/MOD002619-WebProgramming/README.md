# MOD002619 Web Programming — Weeks 1–7 completed

This archive contains the completed practical work grouped by teaching week. Weeks 1–2 are standalone HTML/CSS/JavaScript websites. Weeks 3–6 form one Django student-management project, including the Week 3 rugby-team modelling task. Week 7 is a separate Django SHA256/TDD project, matching the worksheet's instruction to create a new project.

## Folder guide
- `Week01-HTML-CSS/` — responsive two-page site using HTML and CSS only.
- `Week02-JavaScript/` — bill splitter, menu-item bill total, validation and interactive to-do list.
- `Week03-06-Django-StudentPortal/` — Django project: student/module models and M2M relationship, admin, templates, static styling, pagination, filtering, edit/create forms, rugby players/positions M2M and CSV import script.
- `Week07-Django-TDD/hashthat/` — separate Django SHA256 app, database storage, live AJAX preview and unit tests.

## Week 1
Open `Week01-HTML-CSS/index.html` in a browser. The site has two pages and responsive columns/navigation/images. It uses no JavaScript and no CSS framework.

## Week 2
Open `Week02-JavaScript/index.html` in a browser. Add menu items to calculate the bill from their sum, or enter a bill amount directly. Select a tip and number of people, then calculate. Use the to-do section to add, complete and delete tasks. Refreshing clears the list.

## Weeks 3–6 Django project (Windows / VS Code)
Open a terminal in `Week03-06-Django-StudentPortal`:
```powershell
py -m venv venv
.\venv\Scripts\Activate.ps1
python -m pip install -r requirements.txt
python manage.py makemigrations students rugby
python manage.py migrate
python manage.py seed_data
python manage.py runserver
```
Open `http://127.0.0.1:8000/`. Student directory: `/students/`; rugby squad: `/rugby/`; admin: `/admin/`.
Create an admin account with `python manage.py createsuperuser`.
To import the provided student CSV instead of/in addition to seed data, run `python -m pip install django-extensions`, add `django_extensions` to `INSTALLED_APPS`, then run `python manage.py runscript load_students`.

## Week 7 Django TDD project
Open a terminal in `Week07-Django-TDD/hashthat`:
```powershell
py -m venv venv
.\venv\Scripts\Activate.ps1
python -m pip install -r requirements.txt
python manage.py makemigrations
python manage.py migrate
python manage.py test
python manage.py runserver
```
Open `http://127.0.0.1:8000/`. Enter text and submit to view the SHA256 hash. The page also displays a live hash preview using an asynchronous request. Optional Selenium browser test: keep the development server running in one terminal and run `python functional_tests.py` in another after installing Chrome.

## Notes
- `venv/`, local SQLite databases and Python cache files are intentionally not included. Generate migrations locally with the commands above.
- The source worksheet's Chrome binary path was Linux-specific; the Selenium test here lets Selenium Manager locate Chrome on a normal desktop installation.
- The Django secret key is for local coursework only. Do not deploy this development configuration publicly.
