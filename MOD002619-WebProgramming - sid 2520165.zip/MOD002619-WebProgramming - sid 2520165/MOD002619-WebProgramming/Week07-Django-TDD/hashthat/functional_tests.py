"""Optional Selenium browser test. Install Chrome and Selenium before running."""
import unittest
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.chrome.options import Options
class HashingBrowserTest(unittest.TestCase):
    def test_home_page_and_hash(self):
        options=Options()
        options.add_argument("--headless=new")
        driver=webdriver.Chrome(options=options)
        try:
            driver.get("http://127.0.0.1:8000/")
            self.assertIn("Enter text here:",driver.page_source)
            driver.find_element(By.ID,"id_text").send_keys("hello")
            driver.find_element(By.NAME,"submit").click()
            self.assertIn("2cf24dba5fb0a30e26e83b2ac5b9e29e1b161e5c1fa7425e73043362938b9824",driver.page_source)
        finally:
            driver.quit()
if __name__=="__main__": unittest.main()
