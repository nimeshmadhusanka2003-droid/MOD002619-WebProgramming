from django.urls import path
from . import views
app_name="hashing"
urlpatterns=[path("",views.home,name="home"),path("hash/<str:digest>/",views.hash_detail,name="hash_detail"),path("quickhash/",views.quickhash,name="quickhash")]
