from django import forms
class HashForm(forms.Form):
    text=forms.CharField(label="Enter text here:", widget=forms.Textarea(attrs={"rows":4,"placeholder":"Type or paste text to generate its SHA256 hash"}), max_length=10000)
