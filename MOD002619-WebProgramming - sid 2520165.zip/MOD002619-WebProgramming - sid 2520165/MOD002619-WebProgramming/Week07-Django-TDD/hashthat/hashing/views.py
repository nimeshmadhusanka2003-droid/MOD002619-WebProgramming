import hashlib
from django.http import JsonResponse
from django.shortcuts import render, get_object_or_404, redirect
from .forms import HashForm
from .models import Hash

def home(request):
    if request.method=="POST":
        form=HashForm(request.POST)
        if form.is_valid():
            clear_text=form.cleaned_data["text"]
            digest=hashlib.sha256(clear_text.encode("utf-8")).hexdigest()
            Hash.objects.get_or_create(hash=digest, defaults={"text":clear_text})
            return redirect("hashing:hash_detail", digest=digest)
    else:
        form=HashForm()
    return render(request,"hashing/home.html",{"form":form})

def hash_detail(request,digest):
    record=get_object_or_404(Hash,hash=digest)
    return render(request,"hashing/detail.html",{"record":record})

def quickhash(request):
    text=request.GET.get("text","")
    digest=hashlib.sha256(text.encode("utf-8")).hexdigest()
    return JsonResponse({"hash":digest})
