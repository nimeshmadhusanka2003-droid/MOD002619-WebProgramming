import hashlib
from django.test import TestCase
from django.urls import reverse
from .forms import HashForm
from .models import Hash

class HashUnitTests(TestCase):
    def test_hash_form_valid(self):
        self.assertTrue(HashForm(data={"text":"hello"}).is_valid())
    def test_hash_form_rejects_missing_text(self):
        self.assertFalse(HashForm(data={"text":""}).is_valid())
    def test_sha256_hello(self):
        self.assertEqual(hashlib.sha256(b"hello").hexdigest(),"2cf24dba5fb0a30e26e83b2ac5b9e29e1b161e5c1fa7425e73043362938b9824")
    def test_hash_record_is_saved_and_retrieved(self):
        digest=hashlib.sha256(b"hello").hexdigest()
        obj=Hash.objects.create(text="hello",hash=digest)
        self.assertEqual(Hash.objects.get(hash=digest).text,obj.text)
    def test_quickhash_endpoint(self):
        response=self.client.get(reverse("hashing:quickhash"),{"text":"hello"})
        self.assertEqual(response.json()["hash"],hashlib.sha256(b"hello").hexdigest())
    def test_post_redirects_to_hash_page(self):
        response=self.client.post(reverse("hashing:home"),{"text":"hello"})
        self.assertEqual(response.status_code,302)
        self.assertTrue(Hash.objects.filter(text="hello").exists())
    def test_hash_page_displays_original_text(self):
        digest=hashlib.sha256(b"hello").hexdigest()
        Hash.objects.create(text="hello",hash=digest)
        response=self.client.get(reverse("hashing:hash_detail",kwargs={"digest":digest}))
        self.assertContains(response,"hello")
