from django.contrib import admin
from .models import Hash
@admin.register(Hash)
class HashAdmin(admin.ModelAdmin):
    list_display=("hash","created_at")
    search_fields=("text","hash")
