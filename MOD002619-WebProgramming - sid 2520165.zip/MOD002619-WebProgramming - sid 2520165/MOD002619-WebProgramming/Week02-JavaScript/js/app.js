"use strict";
const money = value => `Rs. ${value.toFixed(2)}`;
const itemName = document.getElementById("itemName");
const itemCost = document.getElementById("itemCost");
const itemList = document.getElementById("itemList");
const itemsTotal = document.getElementById("itemsTotal");
const billAmount = document.getElementById("billAmount");
const errors = document.getElementById("errors");
const result = document.getElementById("result");
const menuItems = [];

function renderItems() {
  itemList.replaceChildren();
  menuItems.forEach((item, index) => {
    const li = document.createElement("li");
    const name = document.createElement("span");
    name.textContent = `${item.name} — ${money(item.cost)}`;
    const remove = document.createElement("button");
    remove.textContent = "Remove";
    remove.type = "button";
    remove.addEventListener("click", () => { menuItems.splice(index, 1); renderItems(); });
    li.append(name, remove);
    itemList.append(li);
  });
  const total = menuItems.reduce((sum, item) => sum + item.cost, 0);
  itemsTotal.textContent = money(total);
}
document.getElementById("addItem").addEventListener("click", () => {
  const name = itemName.value.trim();
  const cost = Number(itemCost.value);
  if (!name || itemCost.value === "" || !Number.isFinite(cost) || cost < 0) {
    errors.textContent = "Enter a menu item name and a valid non-negative cost.";
    return;
  }
  menuItems.push({name, cost});
  itemName.value = ""; itemCost.value = ""; errors.textContent = ""; renderItems();
});
document.getElementById("calculate").addEventListener("click", () => {
  errors.textContent = ""; result.textContent = "";
  const amount = menuItems.length ? menuItems.reduce((sum, item) => sum + item.cost, 0) : Number(billAmount.value);
  const people = Number(document.getElementById("people").value);
  const tip = Number(document.getElementById("tipRate").value);
  const problems = [];
  if ((!menuItems.length && billAmount.value === "") || !Number.isFinite(amount) || amount < 0) problems.push("Enter a valid non-negative bill amount or add menu items.");
  if (!Number.isInteger(people) || people < 1) problems.push("Number of people must be a whole number greater than zero.");
  if (problems.length) { errors.textContent = problems.join(" "); return; }
  const tipAmount = amount * tip / 100;
  const grandTotal = amount + tipAmount;
  result.textContent = `Bill: ${money(amount)} · Tip: ${money(tipAmount)} · Total: ${money(grandTotal)} · Each person pays: ${money(grandTotal / people)}`;
});
document.getElementById("addTodo").addEventListener("click", () => {
  const input = document.getElementById("todoInput");
  const value = input.value.trim();
  if (!value) return;
  const li = document.createElement("li");
  const check = document.createElement("input"); check.type = "checkbox"; check.setAttribute("aria-label", `Complete ${value}`);
  const label = document.createElement("span"); label.textContent = value;
  check.addEventListener("change", () => li.classList.toggle("completed", check.checked));
  const remove = document.createElement("button"); remove.textContent = "Delete"; remove.type = "button"; remove.addEventListener("click", () => li.remove());
  li.append(check, label, remove); document.getElementById("todoList").append(li); input.value = "";
});
