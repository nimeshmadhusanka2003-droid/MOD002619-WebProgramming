from django.contrib import admin
from .models import Player, Position
@admin.register(Position)
class PositionAdmin(admin.ModelAdmin):
    list_display = ("name", "specialist")
    list_filter = ("specialist",)
@admin.register(Player)
class PlayerAdmin(admin.ModelAdmin):
    list_display = ("squad_number", "first_name", "last_name")
    search_fields = ("first_name", "last_name")
    filter_horizontal = ("positions",)
