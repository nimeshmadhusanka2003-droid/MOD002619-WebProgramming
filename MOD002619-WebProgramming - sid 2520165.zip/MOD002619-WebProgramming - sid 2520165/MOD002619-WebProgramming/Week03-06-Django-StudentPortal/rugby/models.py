from django.db import models
class Position(models.Model):
    SPECIALIST_POSITIONS = {"Tight Head Prop", "Hooker", "Loose Head Prop", "Second Row"}
    name = models.CharField(max_length=40, unique=True)
    specialist = models.BooleanField(default=False, help_text="Only players specifically assigned to this position should play it.")
    class Meta:
        ordering = ["name"]
    def __str__(self):
        return self.name
class Player(models.Model):
    first_name = models.CharField(max_length=80)
    last_name = models.CharField(max_length=80)
    squad_number = models.PositiveSmallIntegerField(unique=True)
    positions = models.ManyToManyField(Position, related_name="players")
    class Meta:
        ordering = ["squad_number"]
    def __str__(self):
        return f"{self.squad_number} — {self.first_name} {self.last_name}"
