from django.test import TestCase
from .models import Player, Position
class RugbyModelTests(TestCase):
    def test_player_can_have_multiple_positions(self):
        wing = Position.objects.create(name="Left Wing")
        fullback = Position.objects.create(name="Full Back")
        player = Player.objects.create(first_name="Sam", last_name="Silva", squad_number=15)
        player.positions.add(wing, fullback)
        self.assertEqual(player.positions.count(), 2)
