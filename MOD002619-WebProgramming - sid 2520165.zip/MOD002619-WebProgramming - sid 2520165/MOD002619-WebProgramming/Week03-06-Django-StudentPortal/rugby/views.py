from django.shortcuts import render
from .models import Player
def team_list(request):
    return render(request, "rugby/team_list.html", {"players": Player.objects.prefetch_related("positions")})
