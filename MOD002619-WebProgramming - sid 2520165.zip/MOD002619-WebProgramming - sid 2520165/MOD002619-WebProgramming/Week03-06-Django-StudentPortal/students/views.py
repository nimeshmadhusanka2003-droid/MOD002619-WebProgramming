from django.core.paginator import Paginator
from django.shortcuts import get_object_or_404, render, redirect
from django.urls import reverse
from django.utils.http import urlencode
from django.contrib import messages
from .models import Student, Module
from .forms import StudentForm
from .filters import StudentFilter

def home(request):
    return render(request, "students/home.html", {
        "student_count": Student.objects.count(), "module_count": Module.objects.count()
    })

def student_list(request, page=1):
    students = Student.objects.prefetch_related("modules").all()
    student_filter = StudentFilter(request.GET, queryset=students)
    filtered = student_filter.qs.distinct()
    paginator = Paginator(filtered, 8)
    page_obj = paginator.get_page(page)
    query_string = urlencode(request.GET.copy())
    return render(request, "students/student_list.html", {
        "filter": student_filter, "page_obj": page_obj, "query_string": query_string
    })

def student_detail(request, student_id):
    student = get_object_or_404(Student.objects.prefetch_related("modules"), pk=student_id)
    return render(request, "students/student_detail.html", {"student": student})

def student_edit(request, student_id):
    student = get_object_or_404(Student, pk=student_id)
    if request.method == "POST":
        form = StudentForm(request.POST, instance=student)
        if form.is_valid():
            form.save()
            messages.success(request, "Student details updated successfully.")
            return redirect("students:student_detail", student_id=student.pk)
    else:
        form = StudentForm(instance=student)
    return render(request, "students/student_form.html", {"form": form, "student": student})

def student_create(request):
    if request.method == "POST":
        form = StudentForm(request.POST)
        if form.is_valid():
            student = form.save()
            messages.success(request, "Student added successfully.")
            return redirect("students:student_detail", student_id=student.pk)
    else:
        form = StudentForm()
    return render(request, "students/student_form.html", {"form": form})
