import django_filters
from .models import Student
class StudentFilter(django_filters.FilterSet):
    firstName__icontains = django_filters.CharFilter(field_name="firstName", lookup_expr="icontains", label="First name")
    lastName__icontains = django_filters.CharFilter(field_name="lastName", lookup_expr="icontains", label="Last name")
    age__lt = django_filters.NumberFilter(field_name="age", lookup_expr="lt", label="Age less than")
    age__gt = django_filters.NumberFilter(field_name="age", lookup_expr="gt", label="Age greater than")
    modules__code = django_filters.CharFilter(field_name="modules__code", lookup_expr="iexact", label="Module code")
    modules__name__icontains = django_filters.CharFilter(field_name="modules__name", lookup_expr="icontains", label="Module name")
    class Meta:
        model = Student
        fields = []
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.form.fields["firstName__icontains"].label = "First Name"
        self.form.fields["lastName__icontains"].label = "Last Name"
