from django.core.management.base import BaseCommand
from django.utils import timezone
from students.models import Student, Module
from rugby.models import Player, Position
class Command(BaseCommand):
    help = "Create sample student, module, rugby position and player records."
    def handle(self, *args, **options):
        modules = [("MOD002619","Web Programming"),("MOD006560","Computer Modelling and Simulation"),("MOD006128","Distributed Programming")]
        module_objects = {}
        for code,name in modules:
            module_objects[code],_ = Module.objects.get_or_create(code=code, defaults={"name":name})
        samples = [("Amara","Perera",21,"amara@example.com"),("Kavindu","Silva",22,"kavindu@example.com"),("Tharushi","Fernando",20,"tharushi@example.com")]
        for first,last,age,email in samples:
            student,_ = Student.objects.get_or_create(email=email, defaults={"firstName":first,"lastName":last,"age":age,"enrolmentDate":timezone.now()})
            student.modules.add(module_objects["MOD002619"])
        positions = ["Tight Head Prop","Hooker","Loose Head Prop","Second Row","Open Side Flanker","Blind Side Flanker","Number 8","Scrum Half","Fly Half","Inside Centre","Outside Centre","Left Wing","Right Wing","Full Back"]
        for name in positions:
            Position.objects.get_or_create(name=name, defaults={"specialist":name in {"Tight Head Prop","Hooker","Loose Head Prop","Second Row"}})
        for number,first,last,pos in [(1,"Dilan","Perera","Tight Head Prop"),(2,"Kasun","Silva","Hooker"),(15,"Nuwan","Fernando","Full Back")]:
            player,_=Player.objects.get_or_create(squad_number=number, defaults={"first_name":first,"last_name":last})
            player.positions.add(Position.objects.get(name=pos))
        self.stdout.write(self.style.SUCCESS("Sample records are ready."))
