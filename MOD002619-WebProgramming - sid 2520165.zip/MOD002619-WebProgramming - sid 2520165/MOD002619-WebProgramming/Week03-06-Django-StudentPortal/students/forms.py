from django import forms
from .models import Student
class StudentForm(forms.ModelForm):
    class Meta:
        model = Student
        fields = ["firstName", "lastName", "age", "email", "enrolmentDate", "modules"]
        widgets = {"enrolmentDate": forms.DateTimeInput(attrs={"type":"datetime-local"}, format="%Y-%m-%dT%H:%M")}
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.fields["enrolmentDate"].input_formats = ["%Y-%m-%dT%H:%M", "%Y-%m-%d %H:%M:%S%z"]
