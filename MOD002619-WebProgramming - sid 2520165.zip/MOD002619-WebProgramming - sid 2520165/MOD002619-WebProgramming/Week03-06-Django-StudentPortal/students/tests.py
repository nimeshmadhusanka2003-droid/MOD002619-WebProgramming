from django.test import TestCase
from django.urls import reverse
from django.utils import timezone
from .models import Student, Module

class StudentPortalTests(TestCase):
    def setUp(self):
        self.module = Module.objects.create(code="MOD002619", name="Web Programming")
        self.student = Student.objects.create(firstName="Alex", lastName="Perera", age=22,
            email="alex@example.com", enrolmentDate=timezone.now())
        self.student.modules.add(self.module)
    def test_home_page(self):
        response = self.client.get(reverse("students:home"))
        self.assertEqual(response.status_code, 200)
        self.assertContains(response, "Student Portal")
    def test_student_list_and_detail(self):
        self.assertContains(self.client.get(reverse("students:student_list")), "Alex")
        response = self.client.get(reverse("students:student_detail", args=[self.student.pk]))
        self.assertEqual(response.status_code, 200)
        self.assertContains(response, "Web Programming")
    def test_filter_by_first_name(self):
        response = self.client.get(reverse("students:student_list"), {"firstName__icontains":"lex"})
        self.assertContains(response, "Alex")
    def test_student_edit_get(self):
        self.assertEqual(self.client.get(reverse("students:student_edit", args=[self.student.pk])).status_code, 200)
