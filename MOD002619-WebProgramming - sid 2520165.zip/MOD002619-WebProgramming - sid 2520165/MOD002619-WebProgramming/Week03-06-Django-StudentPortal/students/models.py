from django.db import models
from django.urls import reverse

class Module(models.Model):
    code = models.CharField(max_length=10, unique=True)
    name = models.CharField(max_length=100)
    class Meta:
        ordering = ["code"]
    def __str__(self):
        return f"{self.code} — {self.name}"

class Student(models.Model):
    firstName = models.CharField("First name", max_length=100)
    lastName = models.CharField("Last name", max_length=100)
    age = models.PositiveSmallIntegerField()
    email = models.EmailField(blank=True)
    enrolmentDate = models.DateTimeField()
    modules = models.ManyToManyField(Module, blank=True, related_name="students")
    class Meta:
        ordering = ["lastName", "firstName"]
    def __str__(self):
        return f"{self.firstName} {self.lastName}"
    def get_absolute_url(self):
        return reverse("students:student_detail", args=[self.pk])
