import csv
from pathlib import Path
from django.utils import timezone
from students.models import Student, Module

MODULES = {"MOD002619":"Web Programming", "MOD006560":"Computer Modelling and Simulation", "MOD006128":"Distributed Programming"}

def run():
    for code, name in MODULES.items():
        Module.objects.get_or_create(code=code, defaults={"name":name})
    csv_path = Path(__file__).resolve().parent.parent / "data" / "students.csv"
    created = 0
    with csv_path.open(newline="", encoding="utf-8") as file:
        for row in csv.DictReader(file):
            student, was_created = Student.objects.get_or_create(
                email=row["email"],
                defaults={"firstName":row["first_name"], "lastName":row["last_name"],
                          "age":int(row["age"]), "enrolmentDate":timezone.now()})
            created += int(was_created)
            for code in row.get("modules", "").split("|"):
                if code.strip():
                    module = Module.objects.filter(code=code.strip()).first()
                    if module: student.modules.add(module)
    print(f"Imported {created} new students.")
